var express = require('express');
var mysql   = require('mysql');
var router  = express.Router();

var conexion = require('../base_de_datos/redmine.json');//información para conectar con bd
var consulta = require('../consulta/consultar.js');//consulta o query que se hará

router.get('/', function(req, res, next){ res.send('Método get funcionando...'); });

router.post('/', function(req, res, next)
	{
		var conectar = mysql.createConnection(conexion);
		conectar.connect(function(err)
			{
				if (err) 
				{
					console.log('Error al conectar con mysql'+err); throw err;
				}else
				{
					console.log('Conexión a mysql establecida');
				}
			}
		);

		/*
		aquí se leen todos los datos de entrada y se hacen sus respectivas modificaciones
		para poder filtrarlos al archivo con la consulta
		*/

		var sentencia = consulta.sql; 
		console.log('Esta es la consulta: ' + sentencia );//imprimir en consola la consulta

		conectar.query(sentencia, function(err, rows, fields)
			{
				console.log('Realizando consulta...');
				if (!err) 
				{
					conectar.end(function(err)
						{
							if (err) 
							{
								console.log('No se pudo desconectar de Mysql: ' + err); throw err;
							}else
							{
								console.log('Conexión terminada con Mysql');
							}
						}
					);
					res.json(rows);
				}else
				{
					console.log('Error al consultar...');
					conectar.end(function(err)
						{
							if (err) 
							{
								console.log('No se pudo desconectar de Mysql: ' + err); throw err;
							}else
							{
								console.log('Conexión terminada con Mysql');
							}
						}
					);
					res.send('Error al devolver los datos');
				}
			}
		);
	}
);
module.exports = router;