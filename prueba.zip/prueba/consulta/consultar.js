module.exports = 
{
	sql : 'SELECT count(*) FROM bitnami_redmine.groups_users  group by groups_users.group_id' 
};